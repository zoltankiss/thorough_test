class SampleClass
  def self.one_in_float_format
    1.0
  end
end
