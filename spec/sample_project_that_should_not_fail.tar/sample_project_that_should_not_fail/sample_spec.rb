require File.expand_path('../sample', __FILE__)

describe SampleClass do
  it '.one_in_float_format' do
    expect(SampleClass.one_in_float_format).to be_a(Float)
    expect(SampleClass.one_in_float_format).to eq(1)
  end
end
